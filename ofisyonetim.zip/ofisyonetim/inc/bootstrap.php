<?php
define("marka_footer" ,"Edanur");
define("marka_login" ,'<span style="color:#283947;"><b style="color:#f96a44;">Edanur</b> Muslukcu</span>');
define("marka_sidebar" ,"Edanur Muslukcu Proje");


?>