 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
  <!-- Content Header (Page header) -->

<section class="content">

      <!-- Default box -->
      <div class="card card-solid">
        <div class="card-body pb-0">
          <div class="row">
            <div class="col-md-12">
            <div class="info-box mb-3 bg-danger">
              <span class="info-box-icon"><i class="fas fa-smile"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Farklı şeyler deniyorsun.</span>
                <span class="info-box-number">Biz yinede ip adresini alıp kaydımızı tutalım: <?php echo $_SERVER["REMOTE_ADDR"]; ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
          </div>

        </div>
        <!-- /.card-body -->
        <!-- <div class="card-footer">
          <nav aria-label="Contacts Page Navigation">
            <ul class="pagination justify-content-center m-0">
              <li class="page-item active"><a class="page-link" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item"><a class="page-link" href="#">4</a></li>
              <li class="page-item"><a class="page-link" href="#">5</a></li>
              <li class="page-item"><a class="page-link" href="#">6</a></li>
              <li class="page-item"><a class="page-link" href="#">7</a></li>
              <li class="page-item"><a class="page-link" href="#">8</a></li>
            </ul>
          </nav>
        </div> -->
        <!-- /.card-footer -->
      </div>
      <!-- /.card -->

    </section>

  </div>