<?php
$mysqlsunucu = "localhost"; // veritabanı suncusu
$mysqlkullanici = "root"; // veritabanı kullancı adı
$mysqlsifre = ""; // veritabanı şifre
try {
	$db = new PDO("mysql:host=$mysqlsunucu;dbname=ofis1;charset=utf8", $mysqlkullanici, $mysqlsifre);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Bağlantı başarılı"; 
}
catch(PDOException $e) // vt bağlantısının başarılı olup olmadığını kontrol ediyoruz
{
	echo "Bağlantı hatası: " . $e->getMessage();
}


@$username = $_SESSION["username"];
$sql=$db->prepare("SELECT * from user WHERE user_name='$username'"); // kullanıcı adı kontrolü
$sql->execute(); // sorguyu çalıştır
$row=$sql->fetch(PDO::FETCH_ASSOC);
@$user_rol = $row["user_role"];




?>